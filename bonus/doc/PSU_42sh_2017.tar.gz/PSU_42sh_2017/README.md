[![Build Status](https://travis-ci.com/frouioui/42sh.svg?token=XhmJBhJBxshbY6hsWepE&branch=master)](https://travis-ci.com/frouioui/42sh)
# 42sh
Reproduction of the official tcsh shell.
