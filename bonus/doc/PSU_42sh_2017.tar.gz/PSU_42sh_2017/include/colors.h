/*
** EPITECH PROJECT, 2018
** PSU_42sh_2017
** File description:
** Include file for the terminal colors
*/

#ifndef COLORS_H
#define COLORS_H

#define WHITE "\e[39m"
#define CYAN "\e[96m"
#define YELLOW "\e[93m"
#define GREEN "\e[92m"
#define RED "\e[91m"

#endif /* end of include guard: COLORS_H */
