/*
** EPITECH PROJECT, 2018
** PSU_42sh_2017
** File description:
** Contains the read size of the get_next_line function
*/

#ifndef GET_NEXT_LINE_H
#define GET_NEXT_LINE_H

#define READ_SIZE 1

#endif /* end of include guard: GET_NEXT_LINE_H */
