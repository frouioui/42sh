/*
** EPITECH PROJECT, 2018
** PSU_42sh_2017
** File description:
** Display the error command not find.
*/

#include <stdio.h>

void display_error_execution(char *filename)
{
	printf("%s: Command not found.\n", filename);
}
