#!./42sh

ls
