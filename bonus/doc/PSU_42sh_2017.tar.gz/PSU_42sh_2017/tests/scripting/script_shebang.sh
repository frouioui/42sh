!#./42sh

echo toto
