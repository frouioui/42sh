#!42sh

echo toto
