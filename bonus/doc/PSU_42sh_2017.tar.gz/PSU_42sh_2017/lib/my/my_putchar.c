/*
** EPITECH PROJECT, 2018
** PSU_42sh_2017
** File description:
** florent.poinsard@epitech.eu
*/

#include <unistd.h>

void my_putchar(char c)
{
	write(1, &c, 1);
}
